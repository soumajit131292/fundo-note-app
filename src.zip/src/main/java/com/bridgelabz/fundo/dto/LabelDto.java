package com.bridgelabz.fundo.dto;

import lombok.Data;

@Data
public class LabelDto {
private String labelName;
}
