package com.bridgelabz.fundo.dto;

import lombok.Data;
@Data
public class NoteDto {
	private String title;
	private String description;
}
